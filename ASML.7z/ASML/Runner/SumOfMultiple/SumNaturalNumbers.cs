﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SumOfMultiple
{
    public static class SumNaturalNumbers
    {
        public static string Execute(int limit)
        {
            if (limit > 100000) return "You have exceed the limit";

            int Sum = 0; 
            for (int i = 0; i <= limit; i++)
            {
                if ((i % 5 == 0) || (i % 3 == 0))
                {
                    Sum = Sum + i;
                }
            }

            return $"SumOfMultiple is : {Sum}";
        }
    }
}
