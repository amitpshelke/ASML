﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DivisionCheck
{
    public static class Division
    {
        public static int IsXDivisibleByY(int X, int Y)
        {
            int result = (int)((double)X % (double)Y);  // this gives int.MinValue

            int midValue = 0;

            int counter = 32;  //Since we are using int32 as input values

            //below loop is for basically to convert divide by zero ouput of the result to one or zero
            while (counter > 0)
            {
                int logicalAnd = (result & 1);

                midValue = (midValue | logicalAnd);

                result = result >> 1; //shift bit to right once in each loop

                counter--;
            }

            return midValue ^ 1;    //use XOR for to get 1 for success 0 for failure. 
        }
    }
}

/*
(true ^ true);    // output: False
(true ^ false);   // output: True
(false ^ true);   // output: True
(false ^ false);  // output: False 
*/

