﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SequenceAnalysis
{
    public static class FindAndOrderString
    {
        public static string Execute(string input)
        {
            if (string.IsNullOrEmpty(input)) return "You have entered EMPTY string";

            var queryResult = input.Trim().Split(' ')
                                             .Where(s => String.Equals(s, s.ToUpper(), StringComparison.Ordinal))
                                             .Aggregate((i, j) => i + j).ToCharArray();

            return "Result => " + SortIt(queryResult);

        }

        private static string SortIt(char[] array)
        {
            char temp; 
            for (int i = 1; i < array.Length; i++)
            {
                for (int j = 0; j < array.Length - 1; j++)
                {
                    if (array[j] > array[j + 1])
                    {
                        temp = array[j];
                        array[j] = array[j + 1];
                        array[j + 1] = temp;
                    }
                }
            }

            return new string(array);
        }

        private static string SortItLinq(char[] array)
        {
            var sorted = from a in array
                         orderby a
                         select a;

            return new string(sorted.ToArray());
        }

        private static int IsXDivisibleByY(int X, int Y)
        {
            return (X % Y);
        }
    }
}
