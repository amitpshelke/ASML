﻿using SequenceAnalysis;
using SumOfMultiple;
using System;
using DivisionCheck;

namespace Runner
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            bool playIt = true;
            PlayHelp();


            while (playIt)
            {
                Console.WriteLine("Press 1 for SumOfMultiple | Press 2 for SequenceAnalysis | Press 3 for IsXDivisibleByY ==>");

                ConsoleKeyInfo consoleKeyInfo = Console.ReadKey();

                if (consoleKeyInfo.KeyChar == (char)'1')
                {
                    Console.WriteLine($"{Environment.NewLine}Enter the limit (max 100000): ");
                    int limit = 0;
                    int.TryParse(Console.ReadLine(), out limit);
                    Console.WriteLine(SumNaturalNumbers.Execute(limit));
                }

                else if (consoleKeyInfo.KeyChar == (char)'2')
                {
                    Console.WriteLine($"{Environment.NewLine}Enter the desired text: ");
                    Console.WriteLine(FindAndOrderString.Execute(Console.ReadLine()));
                }

                else if (consoleKeyInfo.KeyChar == (char)'3')
                {
                    Console.WriteLine($"{Environment.NewLine}Enter the text: ");
                    string[] data = Console.ReadLine().Trim().Split(',');
                    if(data.Length == 2)
                        Console.WriteLine(Division.IsXDivisibleByY(Convert.ToInt32(data[0]), Convert.ToInt32(data[1])));
                    else
                        Console.WriteLine("Incorrect Input");
                }

                else if (consoleKeyInfo.Key == ConsoleKey.Spacebar)
                {
                    playIt = false;
                }
                else
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Incorrect input");
                    Console.ForegroundColor = ConsoleColor.White;
                }
            }


        }

        private static int IsXDivisibleByY(int X, int Y)
        {
            return (X % Y);
        }

        private static void PlayHelp()
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("Application started to listen your request.");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("Use <SPACEBAR> to stop.");
            Console.ForegroundColor = ConsoleColor.White;
        }
    }
}
